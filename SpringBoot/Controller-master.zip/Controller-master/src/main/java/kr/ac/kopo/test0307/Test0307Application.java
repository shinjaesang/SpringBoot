package kr.ac.kopo.test0307;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Test0307Application {

	public static void main(String[] args) {
		SpringApplication.run(Test0307Application.class, args);
	}

}
