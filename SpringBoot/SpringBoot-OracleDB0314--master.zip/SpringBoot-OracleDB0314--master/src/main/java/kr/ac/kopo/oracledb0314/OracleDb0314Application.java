package kr.ac.kopo.oracledb0314;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OracleDb0314Application {

    public static void main(String[] args) {
        SpringApplication.run(OracleDb0314Application.class, args);
    }

}
